package app.config;

import app.entity.Pedido;

public record NotificationRequestDTO(
		String token, 
		String title,
		String body,
		String id,
		String motivo) {

	public static NotificationRequestDTO from(Pedido p) {
		return new NotificationRequestDTO(
				p.getCliente().getDeviceToken(),
				"Status do seu Pedido",
				p.getStatus().getDescricao(),
				p.getId().toString(),
				null);
	}
	
	public static NotificationRequestDTO cancelado(Pedido p) {
		return new NotificationRequestDTO(
				p.getCliente().getDeviceToken(),
				"Status do seu Pedido",
				p.getStatus().getDescricao(),
				p.getId().toString(),
				p.getMotivoCancel());
	}
	
	public static NotificationRequestDTO entregador(Pedido p) {
		return new NotificationRequestDTO(
				p.getCliente().getDeviceToken(),
				p.getStatus().getDescricao(),
				p.getEntregador().getNome() + " irá entregar seu pedido.",
				p.getId().toString(),
				p.getMotivoCancel());
	}
}
