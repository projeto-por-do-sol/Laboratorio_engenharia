package app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import app.entity.Ingrediente;
import app.entity.Quiosque;

import java.util.Collection;
import java.util.List;


public interface IngredienteRepository extends JpaRepository<Ingrediente, Long> {

	List<Ingrediente> findByNomeInIgnoreCase(Collection<String> nome);
	
	Optional<Ingrediente> findByNomeIgnoreCase(String nome);
	
}
